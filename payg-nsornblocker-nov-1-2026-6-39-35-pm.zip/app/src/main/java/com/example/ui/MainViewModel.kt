package com.example.ui

import android.app.Application
import android.content.Context
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ActivityLogItem
import com.example.data.AppSettings
import com.example.data.DnsProvider
import com.example.data.DpiBypassMode
import com.example.data.SettingsRepository
import com.example.data.ThemeMode
import com.example.data.VpnStats
import com.example.data.VpnStatus
import com.example.vpn.VpnController
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SettingsRepository.getInstance(application)

    val settings: StateFlow<AppSettings> = repository.settings
    val vpnStatus: StateFlow<VpnStatus> = VpnController.status
    val vpnStats: StateFlow<VpnStats> = VpnController.stats
    val activityLogs: StateFlow<List<ActivityLogItem>> = VpnController.activityLogs

    fun toggleVpn(context: Context, onRequirePermission: () -> Unit) {
        if (vpnStatus.value == VpnStatus.CONNECTED || vpnStatus.value == VpnStatus.CONNECTING) {
            VpnController.stopVpn(context)
        } else {
            val vpnIntent = VpnService.prepare(context)
            if (vpnIntent != null) {
                // VPN permission dialog required
                onRequirePermission()
            } else {
                // Already authorized, start directly
                VpnController.startVpn(context)
            }
        }
    }

    fun startVpnDirectly(context: Context) {
        VpnController.startVpn(context)
    }

    fun toggleAdBlock(enabled: Boolean) {
        repository.setAdBlockEnabled(enabled)
    }

    fun toggleDpiBypass(enabled: Boolean) {
        repository.setDpiBypassEnabled(enabled)
    }

    fun setFragmentationSize(size: Int) {
        repository.setFragmentationSize(size)
    }

    fun setDnsProvider(provider: DnsProvider) {
        repository.setDnsProvider(provider)
    }

    fun setCustomDnsIp(ip: String) {
        repository.setCustomDnsIp(ip)
    }

    fun setDpiBypassMode(mode: DpiBypassMode) {
        repository.setDpiBypassMode(mode)
    }

    fun toggleLiquidGlass(enabled: Boolean) {
        repository.setLiquidGlassEnabled(enabled)
    }

    fun setThemeMode(mode: ThemeMode) {
        repository.setThemeMode(mode)
    }

    fun resetStats() {
        VpnController.updateStats {
            VpnStats()
        }
    }
}
