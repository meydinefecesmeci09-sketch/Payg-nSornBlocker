package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ActivityLogItem
import com.example.data.AppSettings
import com.example.data.VpnStats
import com.example.data.VpnStatus
import com.example.ui.components.FooterSignature
import com.example.ui.components.MasterPowerSwitch
import com.example.ui.components.StatsRow
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.RubyRed
import com.example.ui.theme.liquidGlassCard

@Composable
fun DashboardScreen(
    status: VpnStatus,
    stats: VpnStats,
    settings: AppSettings,
    activityLogs: List<ActivityLogItem>,
    onToggleVpn: () -> Unit,
    onToggleAdBlock: (Boolean) -> Unit,
    onToggleDpiBypass: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val isGlass = settings.isLiquidGlassEnabled

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Header
        item {
            Spacer(modifier = Modifier.height(16.dp))
            HeaderBrand(isGlass = isGlass, dnsName = settings.dnsProvider.displayName)
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Master Switch
        item {
            MasterPowerSwitch(
                status = status,
                isLiquidGlass = isGlass,
                onToggle = onToggleVpn,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(26.dp))
        }

        // Live Statistics Row
        item {
            StatsRow(
                stats = stats,
                isLiquidGlass = isGlass,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Quick Controls Card (AdBlock Switch & DPI Bypass Switch)
        item {
            QuickControlsCard(
                isGlass = isGlass,
                isAdBlockEnabled = settings.isAdBlockEnabled,
                isDpiBypassEnabled = settings.isDpiBypassEnabled,
                fragSize = settings.fragmentationSize,
                onToggleAdBlock = onToggleAdBlock,
                onToggleDpiBypass = onToggleDpiBypass
            )
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Live Traffic / Activity Feed
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = CyanNeon,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Canlı Trafik Filtresi",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        if (activityLogs.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .liquidGlassCard(isLiquidGlassEnabled = isGlass, cornerRadius = 18.dp)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (status == VpnStatus.CONNECTED) "Trafik taranıyor ve filtreleniyor..." else "Koruma başladığında engellenen reklamlar burada listelenecektir.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        } else {
            items(activityLogs.take(8), key = { it.id }) { log ->
                ActivityLogCard(log = log, isGlass = isGlass)
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        // Footer signature
        item {
            Spacer(modifier = Modifier.height(16.dp))
            FooterSignature()
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun HeaderBrand(isGlass: Boolean, dnsName: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "PaygınSornBlocker",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Liquid Glass Reklam & DPI Kalkanı",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Active DNS Badge
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .liquidGlassCard(isLiquidGlassEnabled = isGlass, cornerRadius = 16.dp)
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Dns,
                contentDescription = null,
                tint = CyanNeon,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = dnsName,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun QuickControlsCard(
    isGlass: Boolean,
    isAdBlockEnabled: Boolean,
    isDpiBypassEnabled: Boolean,
    fragSize: Int,
    onToggleAdBlock: (Boolean) -> Unit,
    onToggleDpiBypass: (Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlassCard(isLiquidGlassEnabled = isGlass, cornerRadius = 22.dp)
            .padding(16.dp)
    ) {
        Text(
            text = "Hızlı Kontroller",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            letterSpacing = 0.5.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Ad Block Switch
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(RubyRed.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Block,
                        contentDescription = null,
                        tint = RubyRed,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "Reklam Engelleme",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Pop-up, sayaç ve zararlı reklamları filtreler",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Switch(
                checked = isAdBlockEnabled,
                onCheckedChange = onToggleAdBlock,
                modifier = Modifier.testTag("ad_block_switch"),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = RubyRed
                )
            )
        }

        Spacer(modifier = Modifier.height(12.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
        Spacer(modifier = Modifier.height(12.dp))

        // DPI Bypass Switch
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyanNeon.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CallSplit,
                        contentDescription = null,
                        tint = CyanNeon,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "DPI Engelini Aş",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "$fragSize Bayt",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElectricBlue,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(ElectricBlue.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = "Paket parçalama ile sansür ve engelleri atlatır",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Switch(
                checked = isDpiBypassEnabled,
                onCheckedChange = onToggleDpiBypass,
                modifier = Modifier.testTag("dpi_bypass_switch"),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = CyanNeon
                )
            )
        }
    }
}

@Composable
private fun ActivityLogCard(log: ActivityLogItem, isGlass: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlassCard(isLiquidGlassEnabled = isGlass, cornerRadius = 14.dp)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(
                        if (log.isBlocked) RubyRed
                        else if (log.isDpiFragmented) CyanNeon
                        else EmeraldGlow
                    )
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = log.domain,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )
                Text(
                    text = log.statusText,
                    fontSize = 11.sp,
                    color = if (log.isBlocked) RubyRed else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Text(
            text = log.timestamp,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
