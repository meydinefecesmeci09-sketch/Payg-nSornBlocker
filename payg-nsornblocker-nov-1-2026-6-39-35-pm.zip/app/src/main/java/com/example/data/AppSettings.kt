package com.example.data

enum class ThemeMode(val title: String) {
    SYSTEM("Sistem"),
    LIGHT("Açık Tema"),
    DARK("Koyu Tema")
}

enum class DnsProvider(
    val displayName: String,
    val primaryIp: String,
    val secondaryIp: String,
    val description: String
) {
    ADGUARD(
        displayName = "AdGuard DNS",
        primaryIp = "94.140.14.14",
        secondaryIp = "94.140.15.15",
        description = "Reklam, sayaç ve zararlı siteleri filtreler (Önerilen)"
    ),
    CLOUDFLARE(
        displayName = "Cloudflare 1.1.1.1",
        primaryIp = "1.1.1.1",
        secondaryIp = "1.0.0.1",
        description = "Maksimum hız ve gizlilik odaklı DNS"
    ),
    GOOGLE(
        displayName = "Google Public DNS",
        primaryIp = "8.8.8.8",
        secondaryIp = "8.8.4.4",
        description = "Yüksek güvenilirlik ve global ağ"
    ),
    QUAD9(
        displayName = "Quad9 DNS",
        primaryIp = "9.9.9.9",
        secondaryIp = "149.112.112.112",
        description = "Tehdit ve zararlı yazılım korumalı"
    ),
    CUSTOM(
        displayName = "Özel DNS",
        primaryIp = "1.1.1.1",
        secondaryIp = "1.0.0.1",
        description = "Kullanıcı tanımlı DNS sunucusu"
    )
}

enum class DpiBypassMode(val title: String, val description: String) {
    FRAGMENTATION("TCP Segment Parçalama", "İstekleri küçük parçalara bölerek DPI sansürünü atlatır"),
    SNI_SPLIT("SNI Header Bölme", "TLS ClientHello SNI alanını bölerek filtreleri şaşırtır"),
    HTTP_DESYNC("HTTP Host Manipülasyonu", "HTTP Host başlığını çiftleyerek sansürü bypass eder"),
    AUTO("Akıllı Hibrit Mod", "Bağlantıya göre otomatik en iyi DPI atlatma modunu seçer")
}

data class AppSettings(
    val isLiquidGlassEnabled: Boolean = true,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val isAdBlockEnabled: Boolean = true,
    val isDpiBypassEnabled: Boolean = true,
    val fragmentationSize: Int = 2, // 2, 4, 8, 16 bytes
    val dnsProvider: DnsProvider = DnsProvider.ADGUARD,
    val customDnsIp: String = "94.140.14.14",
    val dpiBypassMode: DpiBypassMode = DpiBypassMode.FRAGMENTATION
)
