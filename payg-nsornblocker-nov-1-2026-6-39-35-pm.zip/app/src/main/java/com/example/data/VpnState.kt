package com.example.data

enum class VpnStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED
}

data class VpnStats(
    val blockedAdsCount: Long = 0L,
    val dpiPacketsCount: Long = 0L,
    val safeQueriesCount: Long = 0L,
    val uptimeSeconds: Long = 0L,
    val pingMs: Int = 18
)

data class ActivityLogItem(
    val id: Long = System.currentTimeMillis(),
    val domain: String,
    val statusText: String,
    val isBlocked: Boolean,
    val isDpiFragmented: Boolean,
    val timestamp: String
)
