package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Cyber/Glass Brand Colors
val CyanNeon = Color(0xFF00E5FF)
val CyanBright = Color(0xFF00B4D8)
val ElectricBlue = Color(0xFF0A84FF)
val DeepIndigo = Color(0xFF1E1B4B)
val MidnightDark = Color(0xFF070B14)
val SurfaceDarkNavy = Color(0xFF0D1527)

// Accents
val EmeraldGreen = Color(0xFF10B981)
val EmeraldGlow = Color(0xFF34D399)
val RubyRed = Color(0xFFEF4444)
val AmberWarning = Color(0xFFF59E0B)

// Glass Specific Shaders & Colors
val GlassDarkCard = Color(0x241E293B)
val GlassDarkCardBorder = Color(0x40FFFFFF)
val GlassLightCard = Color(0xC7FFFFFF)
val GlassLightCardBorder = Color(0x660A84FF)
val GlassHighlightSpecular = Color(0x66FFFFFF)

// Material 3 Dark Colors
val DarkPrimary = CyanNeon
val DarkOnPrimary = Color(0xFF00363F)
val DarkPrimaryContainer = Color(0xFF004F5C)
val DarkOnPrimaryContainer = Color(0xFF97F0FF)

val DarkSecondary = ElectricBlue
val DarkOnSecondary = Color(0xFFFFFFFF)
val DarkSecondaryContainer = Color(0xFF00468C)
val DarkOnSecondaryContainer = Color(0xFFD4E3FF)

val DarkBackground = MidnightDark
val DarkOnBackground = Color(0xFFE2E8F0)
val DarkSurface = SurfaceDarkNavy
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)

// Material 3 Light Colors
val LightPrimary = Color(0xFF00687A)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFF97F0FF)
val LightOnPrimaryContainer = Color(0xFF001F26)

val LightSecondary = ElectricBlue
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFD4E3FF)
val LightOnSecondaryContainer = Color(0xFF001C3A)

val LightBackground = Color(0xFFF1F5F9)
val LightOnBackground = Color(0xFF0F172A)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF0F172A)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightOnSurfaceVariant = Color(0xFF475569)
