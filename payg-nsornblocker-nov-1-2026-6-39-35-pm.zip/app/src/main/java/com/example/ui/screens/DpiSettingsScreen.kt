package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppSettings
import com.example.data.DnsProvider
import com.example.data.DpiBypassMode
import com.example.ui.components.FooterSignature
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.liquidGlassCard

@Composable
fun DpiSettingsScreen(
    settings: AppSettings,
    onSelectFragSize: (Int) -> Unit,
    onSelectDns: (DnsProvider) -> Unit,
    onSetCustomDns: (String) -> Unit,
    onSelectDpiMode: (DpiBypassMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val isGlass = settings.isLiquidGlassEnabled
    var showCustomDnsInput by remember { mutableStateOf(settings.dnsProvider == DnsProvider.CUSTOM) }
    var customIpInput by remember { mutableStateOf(settings.customDnsIp) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyanNeon.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = CyanNeon,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "DPI & Ağ Ayarları",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Paket parçalama boyutu ve sansür aşma kuralları",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Section 1: Packet Fragmentation Size
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassCard(isLiquidGlassEnabled = isGlass, cornerRadius = 22.dp)
                    .padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        tint = ElectricBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Paket Parçalama (Fragmentation)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Giden TCP paketlerini küçük parçalara bölerek servis sağlayıcıların (ISP) DPI cihazlarını atlatır.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                val fragSizes = listOf(
                    Triple(2, "2 Bayt", "Maksimum Güvenlik (Önerilen)"),
                    Triple(4, "4 Bayt", "Dengeli Mod (Hızlı ve Güvenli)"),
                    Triple(8, "8 Bayt", "Düşük Gecikme"),
                    Triple(16, "16 Bayt", "Yüksek Hızlı Akış")
                )

                fragSizes.forEach { (size, label, sub) ->
                    val isSelected = settings.fragmentationSize == size
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (isSelected) ElectricBlue.copy(alpha = 0.15f)
                                else Color.Transparent
                            )
                            .clickable { onSelectFragSize(size) }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .testTag("frag_size_$size"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = label,
                                fontSize = 14.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) ElectricBlue else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = sub,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .clip(CircleShape)
                                    .background(ElectricBlue),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Section 2: DNS Selector
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassCard(isLiquidGlassEnabled = isGlass, cornerRadius = 22.dp)
                    .padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Dns,
                        contentDescription = null,
                        tint = CyanNeon,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Güvenli DNS Sunucusu",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Tüm DNS sorgularınızı şifreleyerek ve filtreleyerek sansürü engeller.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                DnsProvider.entries.forEach { provider ->
                    val isSelected = settings.dnsProvider == provider
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (isSelected) CyanNeon.copy(alpha = 0.12f)
                                else Color.Transparent
                            )
                            .clickable {
                                onSelectDns(provider)
                                showCustomDnsInput = provider == DnsProvider.CUSTOM
                            }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                            .testTag("dns_${provider.name.lowercase()}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = {
                                onSelectDns(provider)
                                showCustomDnsInput = provider == DnsProvider.CUSTOM
                            },
                            colors = RadioButtonDefaults.colors(
                                selectedColor = CyanNeon
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = provider.displayName,
                                    fontSize = 14.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = provider.primaryIp,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = provider.description,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                if (showCustomDnsInput) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = customIpInput,
                        onValueChange = {
                            customIpInput = it
                            onSetCustomDns(it)
                        },
                        label = { Text("Özel DNS IP Adresi") },
                        placeholder = { Text("Örn: 94.140.14.14") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("custom_dns_input"),
                        singleLine = true
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Section 3: DPI Strategy
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassCard(isLiquidGlassEnabled = isGlass, cornerRadius = 22.dp)
                    .padding(18.dp)
            ) {
                Text(
                    text = "DPI Atlatma Modu",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(10.dp))

                DpiBypassMode.entries.forEach { mode ->
                    val isSelected = settings.dpiBypassMode == mode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isSelected) ElectricBlue.copy(alpha = 0.12f)
                                else Color.Transparent
                            )
                            .clickable { onSelectDpiMode(mode) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { onSelectDpiMode(mode) },
                            colors = RadioButtonDefaults.colors(selectedColor = ElectricBlue)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = mode.title,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = mode.description,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Footer signature
        item {
            FooterSignature()
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
