package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun Modifier.liquidGlassCard(
    isLiquidGlassEnabled: Boolean,
    cornerRadius: Dp = 24.dp,
    shape: Shape = RoundedCornerShape(cornerRadius),
    strokeWidth: Dp = 1.dp
): Modifier {
    val isDark = isSystemInDarkTheme()

    return if (isLiquidGlassEnabled) {
        val glassBackground = if (isDark) {
            Brush.linearGradient(
                colors = listOf(
                    Color(0xFF1E293B).copy(alpha = 0.55f),
                    Color(0xFF0F172A).copy(alpha = 0.40f),
                    Color(0xFF0284C7).copy(alpha = 0.12f)
                )
            )
        } else {
            Brush.linearGradient(
                colors = listOf(
                    Color(0xFFFFFFFF).copy(alpha = 0.85f),
                    Color(0xFFF0F9FF).copy(alpha = 0.65f),
                    Color(0xFFE0F2FE).copy(alpha = 0.50f)
                )
            )
        }

        val glassStroke = if (isDark) {
            Brush.linearGradient(
                colors = listOf(
                    Color(0xFFFFFFFF).copy(alpha = 0.35f),
                    Color(0xFF00E5FF).copy(alpha = 0.25f),
                    Color(0xFFFFFFFF).copy(alpha = 0.08f)
                )
            )
        } else {
            Brush.linearGradient(
                colors = listOf(
                    Color(0xFFFFFFFF).copy(alpha = 0.90f),
                    Color(0xFF0A84FF).copy(alpha = 0.35f),
                    Color(0xFFBAE6FD).copy(alpha = 0.40f)
                )
            )
        }

        this
            .clip(shape)
            .background(glassBackground, shape)
            .border(BorderStroke(strokeWidth, glassStroke), shape)
    } else {
        // Standard Material 3 Flat Surface Fallback
        val surfaceColor = MaterialTheme.colorScheme.surfaceVariant
        val borderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)

        this
            .clip(shape)
            .background(surfaceColor, shape)
            .border(BorderStroke(strokeWidth, borderColor), shape)
    }
}
