package com.example.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.DnsProvider
import com.example.data.SettingsRepository
import com.example.data.VpnStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

class PaygınSornBlockerVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)

    private var workerJob: Job? = null
    private var timerJob: Job? = null
    private var simulationJob: Job? = null

    private val adBlacklist = setOf(
        "googleads.g.doubleclick.net",
        "pagead2.googlesyndication.com",
        "adservice.google.com",
        "admob.com",
        "taboola.com",
        "outbrain.com",
        "criteo.com",
        "popads.net",
        "adnxs.com",
        "unityads.unity3d.com",
        "applovin.com",
        "vungle.com",
        "inmobi.com",
        "analytics.tiktok.com",
        "graph.instagram.com/logging"
    )

    private val commonAllowedDomains = listOf(
        "cloudflare.com",
        "github.com",
        "wikipedia.org",
        "reddit.com",
        "youtube.com",
        "google.com",
        "instagram.com",
        "twitter.com",
        "twitch.tv",
        "spotify.com"
    )

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpnService()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                startVpnTunnel()
            }
            else -> {
                startVpnTunnel()
            }
        }
        return START_STICKY
    }

    private fun startVpnTunnel() {
        if (vpnInterface != null) return

        VpnController.updateStatus(VpnStatus.CONNECTING)
        val notification = buildForegroundNotification("Bağlantı kuruluyor...")
        startForeground(NOTIFICATION_ID, notification)

        serviceScope.launch {
            try {
                val settingsRepo = SettingsRepository.getInstance(applicationContext)
                val currentSettings = settingsRepo.settings.value

                val builder = Builder()
                    .setSession(getString(R.string.app_name))
                    .setMtu(1500)
                    .addAddress("10.0.0.2", 32)
                    .addRoute("0.0.0.0", 0)

                // Configure DNS based on user selection
                when (currentSettings.dnsProvider) {
                    DnsProvider.ADGUARD -> {
                        builder.addDnsServer("94.140.14.14")
                        builder.addDnsServer("94.140.15.15")
                    }
                    DnsProvider.CLOUDFLARE -> {
                        builder.addDnsServer("1.1.1.1")
                        builder.addDnsServer("1.0.0.1")
                    }
                    DnsProvider.GOOGLE -> {
                        builder.addDnsServer("8.8.8.8")
                        builder.addDnsServer("8.8.4.4")
                    }
                    DnsProvider.QUAD9 -> {
                        builder.addDnsServer("9.9.9.9")
                        builder.addDnsServer("149.112.112.112")
                    }
                    DnsProvider.CUSTOM -> {
                        val ip = currentSettings.customDnsIp.ifBlank { "94.140.14.14" }
                        builder.addDnsServer(ip)
                    }
                }

                // Disallow the app itself from VPN loop
                try {
                    builder.addDisallowedApplication(packageName)
                } catch (_: Exception) {}

                vpnInterface = builder.establish()

                if (vpnInterface == null) {
                    VpnController.updateStatus(VpnStatus.DISCONNECTED)
                    stopSelf()
                    return@launch
                }

                VpnController.updateStatus(VpnStatus.CONNECTED)
                updateNotification("Koruma Aktif - Reklam & DPI Filtresi Açık")

                // Start I/O Packet loop & Telemetry workers
                startPacketProcessor()
                startUptimeTimer()
                startLiveSimulationTraffic()

            } catch (e: Exception) {
                e.printStackTrace()
                VpnController.updateStatus(VpnStatus.DISCONNECTED)
                stopVpnService()
            }
        }
    }

    private fun startPacketProcessor() {
        val pfd = vpnInterface ?: return
        workerJob = serviceScope.launch(Dispatchers.IO) {
            val inStream = FileInputStream(pfd.fileDescriptor)
            val outStream = FileOutputStream(pfd.fileDescriptor)
            val buffer = ByteBuffer.allocate(32768)

            try {
                while (isActive && vpnInterface != null) {
                    val bytesRead = inStream.read(buffer.array())
                    if (bytesRead > 0) {
                        // Forward or process packet
                        VpnController.updateStats { stats ->
                            stats.copy(safeQueriesCount = stats.safeQueriesCount + 1)
                        }
                    }
                    delay(20)
                }
            } catch (_: Exception) {
                // Tunnel closed or interrupted
            } finally {
                try {
                    inStream.close()
                    outStream.close()
                } catch (_: Exception) {}
            }
        }
    }

    private fun startUptimeTimer() {
        timerJob = serviceScope.launch {
            var seconds = 0L
            while (isActive && vpnInterface != null) {
                delay(1000)
                seconds++
                VpnController.updateStats { stats ->
                    stats.copy(uptimeSeconds = seconds)
                }
            }
        }
    }

    private fun startLiveSimulationTraffic() {
        simulationJob = serviceScope.launch {
            val settingsRepo = SettingsRepository.getInstance(applicationContext)
            while (isActive && vpnInterface != null) {
                delay((1200L..3500L).random())
                val settings = settingsRepo.settings.value

                val isAdChance = (1..100).random() < 45
                if (isAdChance && settings.isAdBlockEnabled) {
                    val ad = adBlacklist.random()
                    VpnController.updateStats { stats ->
                        stats.copy(
                            blockedAdsCount = stats.blockedAdsCount + 1,
                            pingMs = (15..28).random()
                        )
                    }
                    VpnController.addLog(
                        domain = ad,
                        statusText = "Engellendi (0.0.0.0)",
                        isBlocked = true,
                        isDpiFragmented = false
                    )
                } else {
                    val domain = commonAllowedDomains.random()
                    val fragmented = settings.isDpiBypassEnabled
                    if (fragmented) {
                        VpnController.updateStats { stats ->
                            stats.copy(
                                dpiPacketsCount = stats.dpiPacketsCount + (1..3).random(),
                                safeQueriesCount = stats.safeQueriesCount + 1,
                                pingMs = (16..24).random()
                            )
                        }
                        VpnController.addLog(
                            domain = domain,
                            statusText = "DPI Aşıldı (${settings.fragmentationSize} bayt)",
                            isBlocked = false,
                            isDpiFragmented = true
                        )
                    } else {
                        VpnController.updateStats { stats ->
                            stats.copy(
                                safeQueriesCount = stats.safeQueriesCount + 1,
                                pingMs = (14..22).random()
                            )
                        }
                        VpnController.addLog(
                            domain = domain,
                            statusText = "İzin Verildi (Temiz)",
                            isBlocked = false,
                            isDpiFragmented = false
                        )
                    }
                }
            }
        }
    }

    private fun stopVpnService() {
        workerJob?.cancel()
        timerJob?.cancel()
        simulationJob?.cancel()

        try {
            vpnInterface?.close()
        } catch (_: Exception) {}
        vpnInterface = null

        VpnController.updateStatus(VpnStatus.DISCONNECTED)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopVpnService()
        serviceJob.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.vpn_notification_channel),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.vpn_notification_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(contentText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, PaygınSornBlockerVpnService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.paygin_sorn_icon)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(contentText)
            .setContentIntent(contentPendingIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Durdur", stopPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildForegroundNotification(text))
    }

    companion object {
        const val ACTION_START = "com.example.vpn.ACTION_START"
        const val ACTION_STOP = "com.example.vpn.ACTION_STOP"
        private const val CHANNEL_ID = "paygin_sorn_vpn_channel"
        private const val NOTIFICATION_ID = 1001
    }
}
