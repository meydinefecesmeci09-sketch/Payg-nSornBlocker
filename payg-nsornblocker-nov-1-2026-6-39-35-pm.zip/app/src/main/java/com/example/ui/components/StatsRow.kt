package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VpnStats
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.RubyRed
import com.example.ui.theme.liquidGlassCard
import java.util.Locale

@Composable
fun StatsRow(
    stats: VpnStats,
    isLiquidGlass: Boolean,
    modifier: Modifier = Modifier
) {
    val uptimeFormatted = formatSeconds(stats.uptimeSeconds)

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(
                title = "Engellenen",
                value = stats.blockedAdsCount.toString(),
                unit = "reklam",
                icon = Icons.Default.Block,
                iconColor = RubyRed,
                isLiquidGlass = isLiquidGlass,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "DPI Parça",
                value = stats.dpiPacketsCount.toString(),
                unit = "paket",
                icon = Icons.Default.CallSplit,
                iconColor = CyanNeon,
                isLiquidGlass = isLiquidGlass,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(
                title = "Aktif Süre",
                value = uptimeFormatted,
                unit = "saat:dk:sn",
                icon = Icons.Default.Timer,
                iconColor = EmeraldGlow,
                isLiquidGlass = isLiquidGlass,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Gecikme",
                value = "${stats.pingMs} ms",
                unit = "${stats.safeQueriesCount} sorgu",
                icon = Icons.Default.Speed,
                iconColor = MaterialTheme.colorScheme.secondary,
                isLiquidGlass = isLiquidGlass,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    unit: String,
    icon: ImageVector,
    iconColor: Color,
    isLiquidGlass: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .liquidGlassCard(isLiquidGlassEnabled = isLiquidGlass, cornerRadius = 18.dp)
            .padding(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = title,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = value,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Text(
            text = unit,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
        )
    }
}

private fun formatSeconds(seconds: Long): String {
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d:%02d", hrs, mins, secs)
}
