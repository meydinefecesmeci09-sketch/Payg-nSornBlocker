package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VpnStatus
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.RubyRed

@Composable
fun MasterPowerSwitch(
    status: VpnStatus,
    isLiquidGlass: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isConnected = status == VpnStatus.CONNECTED
    val isConnecting = status == VpnStatus.CONNECTING

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val buttonScale by animateFloatAsState(
        targetValue = if (isConnected) 1.02f else 1.0f,
        label = "buttonScale"
    )

    val glowColor by animateColorAsState(
        targetValue = when (status) {
            VpnStatus.CONNECTED -> EmeraldGlow
            VpnStatus.CONNECTING -> CyanNeon
            VpnStatus.DISCONNECTED -> Color(0xFF64748B)
        },
        label = "glowColor"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Outer interactive container with pulsing glow waves
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(200.dp)
                .testTag("master_power_switch")
        ) {
            // Pulse wave ring when connected
            if (isConnected) {
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(glowColor.copy(alpha = pulseAlpha))
                        .border(1.dp, glowColor.copy(alpha = pulseAlpha * 1.5f), CircleShape)
                )
                Box(
                    modifier = Modifier
                        .size(175.dp)
                        .scale(pulseScale * 1.1f)
                        .clip(CircleShape)
                        .background(glowColor.copy(alpha = pulseAlpha * 0.4f))
                )
            }

            // Main Central Power Disc
            val centerGradient = if (isConnected) {
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF059669),
                        Color(0xFF047857),
                        Color(0xFF064E3B)
                    )
                )
            } else if (isConnecting) {
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF0284C7),
                        Color(0xFF0369A1),
                        Color(0xFF075985)
                    )
                )
            } else {
                if (isLiquidGlass) {
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF334155).copy(alpha = 0.8f),
                            Color(0xFF1E293B).copy(alpha = 0.9f),
                            Color(0xFF0F172A)
                        )
                    )
                } else {
                    Brush.radialGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surfaceVariant,
                            MaterialTheme.colorScheme.surfaceContainerHigh,
                            MaterialTheme.colorScheme.surfaceContainer
                        )
                    )
                }
            }

            val strokeBrush = if (isConnected) {
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.8f),
                        EmeraldGlow,
                        Color.White.copy(alpha = 0.2f)
                    )
                )
            } else {
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.4f),
                        Color(0xFF94A3B8).copy(alpha = 0.3f),
                        Color.Transparent
                    )
                )
            }

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(136.dp)
                    .scale(buttonScale)
                    .clip(CircleShape)
                    .background(centerGradient)
                    .border(BorderStroke(2.5.dp, strokeBrush), CircleShape)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(bounded = true, radius = 68.dp),
                        onClick = onToggle
                    )
            ) {
                if (isConnecting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(56.dp),
                        color = Color.White,
                        strokeWidth = 3.5.dp
                    )
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = if (isConnected) "Korumayı Durdur" else "Korumayı Başlat",
                            tint = if (isConnected) Color.White else Color(0xFFE2E8F0),
                            modifier = Modifier.size(54.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Status pill badge with pulsing icon
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (isConnected) EmeraldGreen.copy(alpha = 0.15f)
                    else if (isConnecting) CyanNeon.copy(alpha = 0.15f)
                    else Color(0xFF64748B).copy(alpha = 0.15f)
                )
                .border(
                    1.dp,
                    if (isConnected) EmeraldGreen.copy(alpha = 0.4f)
                    else if (isConnecting) CyanNeon.copy(alpha = 0.4f)
                    else Color(0xFF64748B).copy(alpha = 0.3f),
                    RoundedCornerShape(20.dp)
                )
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(glowColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = when (status) {
                    VpnStatus.CONNECTED -> "KORUMA AKTİF"
                    VpnStatus.CONNECTING -> "BAĞLANILIYOR…"
                    VpnStatus.DISCONNECTED -> "KORUMA DEVRE DIŞI"
                },
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (isConnected) EmeraldGlow else MaterialTheme.colorScheme.onSurface,
                letterSpacing = 0.8.sp
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = when (status) {
                VpnStatus.CONNECTED -> "Reklam filtreleme ve DPI tüneli devrede"
                VpnStatus.CONNECTING -> "Güvenli tünel kuruluyor..."
                VpnStatus.DISCONNECTED -> "Tüm filtreleri açmak için şaltere dokunun"
            },
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
