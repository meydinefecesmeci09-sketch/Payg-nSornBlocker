package com.example

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.AmbientBackground
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DpiSettingsScreen
import com.example.ui.screens.GeneralSettingsScreen
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.PaygınSornBlockerTheme
import com.example.ui.theme.liquidGlassCard

enum class ScreenTab(val title: String, val activeIcon: ImageVector, val inactiveIcon: ImageVector) {
    DASHBOARD("Koruma", Icons.Filled.Shield, Icons.Outlined.Shield),
    DPI_SETTINGS("DPI & Ağ", Icons.Filled.Layers, Icons.Outlined.Layers),
    SETTINGS("Ayarlar", Icons.Filled.Settings, Icons.Outlined.Settings)
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by viewModel.settings.collectAsState()
            val vpnStatus by viewModel.vpnStatus.collectAsState()
            val vpnStats by viewModel.vpnStats.collectAsState()
            val activityLogs by viewModel.activityLogs.collectAsState()

            val context = LocalContext.current
            var currentTab by remember { mutableStateOf(ScreenTab.DASHBOARD) }

            // Handle Back Button to return to Dashboard tab
            BackHandler(enabled = currentTab != ScreenTab.DASHBOARD) {
                currentTab = ScreenTab.DASHBOARD
            }

            // VPN Permission Result Launcher
            val vpnPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.StartActivityForResult()
            ) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    viewModel.startVpnDirectly(context)
                } else {
                    Toast.makeText(
                        context,
                        getString(R.string.vpn_permission_required),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            PaygınSornBlockerTheme(themeMode = settings.themeMode) {
                AmbientBackground(
                    isLiquidGlass = settings.isLiquidGlassEnabled,
                    isVpnActive = vpnStatus == com.example.data.VpnStatus.CONNECTED
                ) {
                    Scaffold(
                        containerColor = Color.Transparent,
                        bottomBar = {
                            LiquidGlassBottomBar(
                                currentTab = currentTab,
                                isGlass = settings.isLiquidGlassEnabled,
                                onTabSelected = { currentTab = it },
                                modifier = Modifier.navigationBarsPadding()
                            )
                        },
                        modifier = Modifier.fillMaxSize()
                    ) { innerPadding ->
                        AnimatedContent(
                            targetState = currentTab,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding),
                            label = "tabTransition"
                        ) { tab ->
                            when (tab) {
                                ScreenTab.DASHBOARD -> DashboardScreen(
                                    status = vpnStatus,
                                    stats = vpnStats,
                                    settings = settings,
                                    activityLogs = activityLogs,
                                    onToggleVpn = {
                                        viewModel.toggleVpn(context) {
                                            val prepareIntent = VpnService.prepare(context)
                                            if (prepareIntent != null) {
                                                vpnPermissionLauncher.launch(prepareIntent)
                                            }
                                        }
                                    },
                                    onToggleAdBlock = viewModel::toggleAdBlock,
                                    onToggleDpiBypass = viewModel::toggleDpiBypass
                                )

                                ScreenTab.DPI_SETTINGS -> DpiSettingsScreen(
                                    settings = settings,
                                    onSelectFragSize = viewModel::setFragmentationSize,
                                    onSelectDns = viewModel::setDnsProvider,
                                    onSetCustomDns = viewModel::setCustomDnsIp,
                                    onSelectDpiMode = viewModel::setDpiBypassMode
                                )

                                ScreenTab.SETTINGS -> GeneralSettingsScreen(
                                    settings = settings,
                                    onToggleLiquidGlass = viewModel::toggleLiquidGlass,
                                    onSelectThemeMode = viewModel::setThemeMode,
                                    onResetStats = viewModel::resetStats
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LiquidGlassBottomBar(
    currentTab: ScreenTab,
    isGlass: Boolean,
    onTabSelected: (ScreenTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 10.dp)
            .testTag("liquid_glass_bottom_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlassCard(isLiquidGlassEnabled = isGlass, cornerRadius = 26.dp)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ScreenTab.entries.forEach { tab ->
                val isSelected = currentTab == tab
                val icon = if (isSelected) tab.activeIcon else tab.inactiveIcon
                val contentColor = if (isSelected) CyanNeon else MaterialTheme.colorScheme.onSurfaceVariant

                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(bounded = true, radius = 32.dp),
                            onClick = { onTabSelected(tab) }
                        )
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .testTag("tab_${tab.name.lowercase()}"),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = tab.title,
                        tint = contentColor,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = tab.title,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = contentColor
                    )
                }
            }
        }
    }
}
