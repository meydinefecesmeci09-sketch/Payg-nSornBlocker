package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepository private constructor(context: Context) {

    private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun loadSettings(): AppSettings {
        val liquidGlass = prefs.getBoolean(KEY_LIQUID_GLASS, true)
        val themeModeStr = prefs.getString(KEY_THEME_MODE, ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name
        val themeMode = try {
            ThemeMode.valueOf(themeModeStr)
        } catch (_: Exception) {
            ThemeMode.SYSTEM
        }
        val adBlock = prefs.getBoolean(KEY_AD_BLOCK, true)
        val dpiBypass = prefs.getBoolean(KEY_DPI_BYPASS, true)
        val fragSize = prefs.getInt(KEY_FRAG_SIZE, 2)
        val dnsStr = prefs.getString(KEY_DNS, DnsProvider.ADGUARD.name) ?: DnsProvider.ADGUARD.name
        val dnsProvider = try {
            DnsProvider.valueOf(dnsStr)
        } catch (_: Exception) {
            DnsProvider.ADGUARD
        }
        val customDns = prefs.getString(KEY_CUSTOM_DNS, "94.140.14.14") ?: "94.140.14.14"
        val dpiModeStr = prefs.getString(KEY_DPI_MODE, DpiBypassMode.FRAGMENTATION.name) ?: DpiBypassMode.FRAGMENTATION.name
        val dpiMode = try {
            DpiBypassMode.valueOf(dpiModeStr)
        } catch (_: Exception) {
            DpiBypassMode.FRAGMENTATION
        }

        return AppSettings(
            isLiquidGlassEnabled = liquidGlass,
            themeMode = themeMode,
            isAdBlockEnabled = adBlock,
            isDpiBypassEnabled = dpiBypass,
            fragmentationSize = fragSize,
            dnsProvider = dnsProvider,
            customDnsIp = customDns,
            dpiBypassMode = dpiMode
        )
    }

    fun setLiquidGlassEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_LIQUID_GLASS, enabled).apply()
        _settings.value = _settings.value.copy(isLiquidGlassEnabled = enabled)
    }

    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
        _settings.value = _settings.value.copy(themeMode = mode)
    }

    fun setAdBlockEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AD_BLOCK, enabled).apply()
        _settings.value = _settings.value.copy(isAdBlockEnabled = enabled)
    }

    fun setDpiBypassEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_DPI_BYPASS, enabled).apply()
        _settings.value = _settings.value.copy(isDpiBypassEnabled = enabled)
    }

    fun setFragmentationSize(size: Int) {
        prefs.edit().putInt(KEY_FRAG_SIZE, size).apply()
        _settings.value = _settings.value.copy(fragmentationSize = size)
    }

    fun setDnsProvider(provider: DnsProvider) {
        prefs.edit().putString(KEY_DNS, provider.name).apply()
        _settings.value = _settings.value.copy(dnsProvider = provider)
    }

    fun setCustomDnsIp(ip: String) {
        prefs.edit().putString(KEY_CUSTOM_DNS, ip).apply()
        _settings.value = _settings.value.copy(customDnsIp = ip)
    }

    fun setDpiBypassMode(mode: DpiBypassMode) {
        prefs.edit().putString(KEY_DPI_MODE, mode.name).apply()
        _settings.value = _settings.value.copy(dpiBypassMode = mode)
    }

    companion object {
        private const val PREFS_NAME = "paygin_sorn_prefs"
        private const val KEY_LIQUID_GLASS = "key_liquid_glass"
        private const val KEY_THEME_MODE = "key_theme_mode"
        private const val KEY_AD_BLOCK = "key_ad_block"
        private const val KEY_DPI_BYPASS = "key_dpi_bypass"
        private const val KEY_FRAG_SIZE = "key_frag_size"
        private const val KEY_DNS = "key_dns"
        private const val KEY_CUSTOM_DNS = "key_custom_dns"
        private const val KEY_DPI_MODE = "key_dpi_mode"

        @Volatile
        private var INSTANCE: SettingsRepository? = null

        fun getInstance(context: Context): SettingsRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SettingsRepository(context).also { INSTANCE = it }
            }
        }
    }
}
