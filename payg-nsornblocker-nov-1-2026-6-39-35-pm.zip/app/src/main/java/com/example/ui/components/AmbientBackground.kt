package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldGlow
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AmbientBackground(
    isLiquidGlass: Boolean,
    isVpnActive: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val isDark = isSystemInDarkTheme()

    val infiniteTransition = rememberInfiniteTransition(label = "ambient")
    val animProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f, // 2 * PI
        animationSpec = infiniteRepeatable(
            animation = tween(18000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbMovement"
    )

    val baseBackground = if (isDark) {
        Color(0xFF090D16)
    } else {
        Color(0xFFF1F5F9)
    }

    Box(modifier = modifier.fillMaxSize().background(baseBackground)) {
        if (isLiquidGlass) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                // Orb 1: Cyan / Emerald floating top-right
                val orb1X = width * 0.75f + cos(animProgress) * (width * 0.15f)
                val orb1Y = height * 0.22f + sin(animProgress) * (height * 0.12f)
                val orb1Color = if (isVpnActive) EmeraldGlow else CyanNeon
                val orb1Alpha = if (isDark) 0.18f else 0.12f

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(orb1Color.copy(alpha = orb1Alpha), Color.Transparent),
                        center = Offset(orb1X, orb1Y),
                        radius = width * 0.70f
                    ),
                    center = Offset(orb1X, orb1Y),
                    radius = width * 0.70f
                )

                // Orb 2: Electric Blue floating middle-left
                val orb2X = width * 0.25f + sin(animProgress * 0.8f) * (width * 0.18f)
                val orb2Y = height * 0.65f + cos(animProgress * 0.8f) * (height * 0.15f)
                val orb2Alpha = if (isDark) 0.16f else 0.10f

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(ElectricBlue.copy(alpha = orb2Alpha), Color.Transparent),
                        center = Offset(orb2X, orb2Y),
                        radius = width * 0.75f
                    ),
                    center = Offset(orb2X, orb2Y),
                    radius = width * 0.75f
                )

                // Orb 3: Violet / Indigo subtle accent top-left
                val orb3X = width * 0.20f + cos(animProgress * 1.2f) * (width * 0.10f)
                val orb3Y = height * 0.12f + sin(animProgress * 1.2f) * (height * 0.08f)
                val orb3Color = Color(0xFF6366F1)
                val orb3Alpha = if (isDark) 0.12f else 0.08f

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(orb3Color.copy(alpha = orb3Alpha), Color.Transparent),
                        center = Offset(orb3X, orb3Y),
                        radius = width * 0.55f
                    ),
                    center = Offset(orb3X, orb3Y),
                    radius = width * 0.55f
                )
            }
        }

        content()
    }
}
