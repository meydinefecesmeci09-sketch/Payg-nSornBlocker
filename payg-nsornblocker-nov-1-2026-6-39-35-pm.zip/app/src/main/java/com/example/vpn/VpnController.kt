package com.example.vpn

import android.content.Context
import android.content.Intent
import com.example.data.ActivityLogItem
import com.example.data.VpnStats
import com.example.data.VpnStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object VpnController {

    private val _status = MutableStateFlow(VpnStatus.DISCONNECTED)
    val status: StateFlow<VpnStatus> = _status.asStateFlow()

    private val _stats = MutableStateFlow(VpnStats())
    val stats: StateFlow<VpnStats> = _stats.asStateFlow()

    private val _activityLogs = MutableStateFlow<List<ActivityLogItem>>(emptyList())
    val activityLogs: StateFlow<List<ActivityLogItem>> = _activityLogs.asStateFlow()

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun updateStatus(newStatus: VpnStatus) {
        _status.value = newStatus
        if (newStatus == VpnStatus.DISCONNECTED) {
            _stats.value = _stats.value.copy(uptimeSeconds = 0)
        }
    }

    fun updateStats(transform: (VpnStats) -> VpnStats) {
        _stats.value = transform(_stats.value)
    }

    fun addLog(domain: String, statusText: String, isBlocked: Boolean, isDpiFragmented: Boolean) {
        val newItem = ActivityLogItem(
            id = System.currentTimeMillis() + (0..1000).random(),
            domain = domain,
            statusText = statusText,
            isBlocked = isBlocked,
            isDpiFragmented = isDpiFragmented,
            timestamp = timeFormat.format(Date())
        )
        val current = _activityLogs.value.toMutableList()
        current.add(0, newItem)
        if (current.size > 50) {
            _activityLogs.value = current.take(50)
        } else {
            _activityLogs.value = current
        }
    }

    fun startVpn(context: Context) {
        val intent = Intent(context, PaygınSornBlockerVpnService::class.java).apply {
            action = PaygınSornBlockerVpnService.ACTION_START
        }
        context.startForegroundService(intent)
    }

    fun stopVpn(context: Context) {
        val intent = Intent(context, PaygınSornBlockerVpnService::class.java).apply {
            action = PaygınSornBlockerVpnService.ACTION_STOP
        }
        context.startService(intent)
    }
}
